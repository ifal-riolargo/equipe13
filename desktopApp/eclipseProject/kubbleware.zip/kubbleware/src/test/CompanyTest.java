package test;

import app.information.Course;
import app.company.Company;

public class CompanyTest {
	public static void main(String[] args) {
		Course[] courses = new Course[3];
		
		String[] bibliographyInformatica = { "b1", "b2" };
		Course informatica = new Course("Informatica topdao", "conteudoDeInfor", "descricao do curso caraINFOR", bibliographyInformatica, 800, 'A', "caminho/do/cursoInformatica");
		String[] bibliographyEngsoftware = { "b3", "b4" };
		Course engsoftware = new Course("Engenharia de software", "conteudoDeEg", "descricao do curso caraENG", bibliographyEngsoftware, 800, 'A', "caminho/do/cursoEngsfotware");
		String[] bibliographyPoo = { "b5", "b6" };
		Course poo = new Course("poo", "conteudoDePOO", "descricao do curso caraPOP", bibliographyPoo, 800, 'A', "caminho/do/cursoPoo");
		
		courses[0] = informatica;
		courses[1] = engsoftware;
		courses[2] = poo;
				
				
		Company kubbleware = new Company("Kubbleware", "123123123", "endereco", "contato", 10, courses, "nossa empresa faz isso isso e aquilo");
		
		System.out.println(kubbleware.getName());
		System.out.println(kubbleware.getAbout());
		System.out.println("Cursos");
		kubbleware.listCourses();
	}
}
