package app.company;

import app.information.Course;

public class Company {
	private String name = "";
	private String cnpj = "";
	private String address = "";
	private String contact = "";
	private String about = "";
	private Course[] courses;
	
	/**
	 * 
	 * @param name
	 * @param cnpj
	 * @param address
	 * @param contact
	 * @param amountCourses
	 * @param courses
	 */
	public Company(String name, String cnpj, String address, String contact, int amountCourses, Course[] courses, String about) {
		this.name = name;
		this.cnpj = cnpj;
		this.address = address;
		this.contact = contact;
		this.courses = courses;
		this.about = about;
	}
	
	/**
	 * 
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}
	
	
	/**
	 * 
	 * @param cnpj
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * 
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	
	/**
	 * 
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * 
	 * @return the contact
	 */
	public String getContact() {
		return contact;
	}

	/**
	 * 
	 * @param contact
	 */
	public void setContact(String contact) {
		this.contact = contact;
	}

	/**
	 * 
	 * @return the courses[]
	 */
	public Course[] getCourses() {
		return courses;
	}
	
	/**
	 * 
	 * @param courses
	 */
	public void setCourses(Course[] courses) {
		this.courses = courses;
	}
	
	/**
	 * 
	 * @return the about
	 */
	public String getAbout() {
		return this.about;
	}
	
	/**
	 * 
	 * @param about
	 */
	public void setAbout(String about) {
		this.about = about;
	}
	
	/**
	 * 
	 * @return void
	 */
	public void listCourses() {
		for(Course course : this.courses) {
			System.out.println(course.getTitle());
		}
	}
	
}
