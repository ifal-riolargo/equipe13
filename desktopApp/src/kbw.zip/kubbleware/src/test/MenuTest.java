package test;

import app.userinterface.Menu;

public class MenuTest {
  public static void main(String[] args) {
    Menu mainMenu = new Menu();

    mainMenu.showMenu();

  }
}
